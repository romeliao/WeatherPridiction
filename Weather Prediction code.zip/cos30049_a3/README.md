#commands to install before running the code 
- npm install  
- npm install react-router-dom  
- npm install react-icons 
- npm install chart.js 
- npm install react-chartjs-2 chart.js 
- npm install react-plotly.js 
- npm install axios
- pip install fastapi uvicorn
- pip install pandas
- pip install joblib


Once the libraries above have been install to run the code:
enter into the backend terminal 
![image](https://github.com/user-attachments/assets/fa2cb675-c8cc-43b6-8267-37e7b73f57b3)

 
 run the command 
 - uvicorn main:app --reload to start the back end server 


once the server is running you will need to go into the frontend terminal 
to do this open a new terminal and enter into the front end terminal 
![image](https://github.com/user-attachments/assets/07717e70-cd57-4ca0-8529-bd32bb395f52)


run the command to start the website 
- npm start 
