// Import all images
import Kim from './Kim.jpg';
import Jerome from './Jerome.jpg';
import Matt from './Matt.jpg';
import logo from './SkyCastLogoTransparent.png';
import report from './report.pdf';

// Export images for easy access
export { Kim, Jerome, Matt ,logo, report};
