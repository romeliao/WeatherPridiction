import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './WeatherForecast.css';

const WeatherForecast = () => {
  const [location, setLocation] = useState('');
  const [forecastData, setForecastData] = useState(null);
  const [error, setError] = useState('');
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const fetchWeatherData = async (location) => {
    try {
        const apiKey = 'a255a43ceaa037bdfcd716172e6a2107'; // Replace with your actual API key

        // Fetch current weather data
        const response = await axios.get(
            `https://api.openweathermap.org/data/2.5/weather?q=${location}&units=metric&appid=${apiKey}`
        );

        // Fetch forecast data
        const forecastResponse = await axios.get(
            `https://api.openweathermap.org/data/2.5/forecast?q=${location}&units=metric&appid=${apiKey}`
        );

        // Prepare weather info
        const weatherInfo = {
            city: response.data.name,
            state: response.data.weather[0].description,
            icon: response.data.weather[0].icon,
            temperatureC: response.data.main.temp,
            realFeel: response.data.main.feels_like,
            humidity: response.data.main.humidity,
            windSpeed: response.data.wind.speed,
            sunrise: new Date(response.data.sys.sunrise * 1000).toLocaleTimeString(),
            sunset: new Date(response.data.sys.sunset * 1000).toLocaleTimeString(),
            minTemp: response.data.main.temp_min, // Extracted min temperature
            maxTemp: response.data.main.temp_max, // Extracted max temperature
            forecasts: forecastResponse.data.list.slice(0, 8), // Get 3-hour steps
            dailyForecasts: getDailyForecasts(forecastResponse.data.list), // Get daily forecast
            rainForecasts: getRainForecasts(forecastResponse.data.list) // Get rainfall data
        };

        setForecastData(weatherInfo);
        setError('');

        // Send data to prediction API
        await axios.put('http://127.0.0.1:8000/put/data', null, {
            params: {
                MinTemp: weatherInfo.minTemp,
                MaxTemp: weatherInfo.maxTemp,
                Rainfall: weatherInfo.rainForecasts.reduce((acc, val) => acc + val.rainAmount, 0) // Total rainfall
            }
        });
        
    } catch (err) {
        setError('Failed to fetch weather data. Please try again.');
    }
  };

  const getDailyForecasts = (list) => {
    const daily = {};
    list.forEach((item) => {
      const date = new Date(item.dt * 1000).toLocaleDateString();
      if (!daily[date]) {
        daily[date] = { tempMax: item.main.temp, icon: item.weather[0].icon };
      } else {
        daily[date].tempMax = Math.max(daily[date].tempMax, item.main.temp);
      }
    });
    return Object.entries(daily).slice(0, 7); // Get the next 7 days including today
  };

  const getRainForecasts = (list) => {
    return list.map(item => ({
      time: new Date(item.dt * 1000).toLocaleTimeString(),
      rainAmount: item.rain ? item.rain['3h'] || 0 : 0, // Rain in the last 3 hours
      description: item.weather[0].description
    }));
  };

  const handleLocationClick = (location) => {
    fetchWeatherData(location);
    setLocation(location);
  };

  const handleInputChange = (e) => {
    setLocation(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (location) {
      fetchWeatherData(location);
    }
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        fetchWeatherData(`lat=${latitude}&lon=${longitude}`);
      });
    } else {
      setError('Geolocation is not supported by this browser.');
    }
  };

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentDate(new Date());
    }, 1000);
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="weather-forecast-container">
      <div className="location-buttons">
        <button onClick={() => handleLocationClick('London')}>London</button>
        <button onClick={() => handleLocationClick('Sydney')}>Sydney</button>
        <button onClick={() => handleLocationClick('Tokyo')}>Tokyo</button>
        <button onClick={() => handleLocationClick('Paris')}>Paris</button>
        <button onClick={() => handleLocationClick('Toronto')}>Toronto</button>
      </div>

      <form onSubmit={handleSubmit} className="search-form">
        <input
          type="text"
          placeholder="Search by city"
          value={location}
          onChange={handleInputChange}
        />
        <button type="submit">Search</button>
      </form>

      {error && <p className="error">{error}</p>}

      {forecastData && (
        <div>
          <h2>{forecastData.city}</h2>
          <div className="temp">
            {`${forecastData.temperatureC.toFixed(1)}°C`}
          </div>
          <img
            src={`https://openweathermap.org/img/wn/${forecastData.icon}@2x.png`}
            alt={forecastData.state}
            className="weather-icon"
          />
          <p>{forecastData.state}</p>

          <div className="weather-details">
            <div>Real Feel: {forecastData.realFeel.toFixed(1)}°C</div>
            <div>Humidity: {forecastData.humidity}%</div>
            <div>Wind: {forecastData.windSpeed} km/h</div>
            <div>Sunrise: {forecastData.sunrise}</div>
            <div>Sunset: {forecastData.sunset}</div>
          </div>

          <h3>3-Hour Forecasts</h3>
          <div className="forecast-list">
            {forecastData.forecasts.map((forecast, index) => (
              <div key={index} className="forecast-item">
                <p>{new Date(forecast.dt * 1000).toLocaleTimeString()}</p>
                <p>{forecast.main.temp.toFixed(1)}°C</p>
                <img
                  src={`https://openweathermap.org/img/wn/${forecast.weather[0].icon}@2x.png`}
                  alt={forecast.weather[0].description}
                  className="forecast-icon"
                />
                <p>{forecast.weather[0].description}</p>
                <p>Rainfall: {forecastData.rainForecasts[index] ? `${forecastData.rainForecasts[index].rainAmount} mm` : 'N/A'}</p>
              </div>
            ))}
          </div>

          <h3>Daily Forecast</h3>
          <div className="daily-forecast">
            {forecastData.dailyForecasts.map(([date, daily], index) => (
              <div key={index} className="daily-forecast-item">
                <p>{date}</p>
                <img
                  src={`https://openweathermap.org/img/wn/${daily.icon}@2x.png`}
                  alt="daily weather icon"
                  className="forecast-icon"
                />
                <p>{daily.tempMax.toFixed(1)}°C</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default WeatherForecast;