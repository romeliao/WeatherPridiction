import React, { useState, useEffect } from 'react'; // Import necessary React libraries
import axios from 'axios'; // Import axios for making API requests
import WeatherChart from './WeatherChart'; // Import the WeatherChart component
import RainTodayChart from './RainTodayChart'; // Import the RainTodayChart component
import './Home.css'; // Import styles for this component
import WeatherForecast from './WeatherForecast';
import WeatherPrediction from './WeatherPrediction';

const Home = () => {
  // State variables to manage location, weather data, errors, and auto-update settings
  const [location, setLocation] = useState(''); // For storing the city name input
  const [weatherData, setWeatherData] = useState(null); // To hold fetched weather data
  const [error, setError] = useState(''); // To hold any error messages
  const [autoUpdate, setAutoUpdate] = useState(false); // To manage auto-update functionality

  // Function to fetch weather data from the API
  const fetchWeatherData = async (location) => {
    try {
      const apiKey = 'a255a43ceaa037bdfcd716172e6a2107'; // Your OpenWeatherMap API key
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/forecast?q=${location}&units=metric&appid=${apiKey}`
      );

      // Extract data from the API response
      const allDates = response.data.list.map((item) => item.dt_txt); // Dates from the forecast
      const allMinTemp = response.data.list.map((item) => item.main.temp_min); // Minimum temperatures
      const allMaxTemp = response.data.list.map((item) => item.main.temp_max); // Maximum temperatures
      const allRainToday = response.data.list.map((item) => (item.rain ? 1 : 0)); // Rain presence (1 if rain, else 0)

      const today = new Date().toISOString().slice(0, 10); // Get today's date
      const hourlyData = response.data.list.filter((item) => item.dt_txt.startsWith(today)); // Filter for today's data

      // Prepare hourly weather data
      const hourlyDates = hourlyData.map((item) => item.dt_txt); // Hourly dates
      const hourlyMinTemp = hourlyData.map((item) => item.main.temp_min); // Hourly minimum temperatures
      const hourlyMaxTemp = hourlyData.map((item) => item.main.temp_max); // Hourly maximum temperatures

      // Set the fetched weather data into state
      setWeatherData({
        city: response.data.city.name, // City name
        dates: allDates,
        minTemp: allMinTemp,
        maxTemp: allMaxTemp,
        hourlyDates,
        hourlyMinTemp,
        hourlyMaxTemp,
        rainToday: allRainToday,
      });
      setError(''); // Clear any previous error
    } catch (err) {
      // Handle any errors during the API request
      setError('Failed to fetch weather data. Please try again.');
    }
  };

  // useEffect to handle side effects
  useEffect(() => {
    let interval; // Variable to hold the interval ID
    // Check if auto-update is enabled and location is set
    if (autoUpdate && location) {
      fetchWeatherData(location); // Fetch weather data
      // Set an interval to auto-fetch weather data every 5 minutes
      interval = setInterval(() => {
        fetchWeatherData(location);
      }, 300000); // 5 minutes in milliseconds
    }
    return () => clearInterval(interval); // Cleanup the interval on component unmount
  }, [autoUpdate, location]); // Dependencies: re-run effect when autoUpdate or location changes

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the default form submission
    if (location) {
      fetchWeatherData(location); // Fetch weather data for the entered location
    }
  };

  // Render the component
  return (
    <div className="home-container">
      <WeatherForecast/>
      {/* Weather Prediction Section */}
      <div className="weather-info">
        <h1>Weather Prediction</h1>
        <WeatherPrediction /> {/* Show rain and temperature predictions */}
      </div>
      <div className="weather-info">
        <h1>Data Visualization</h1>
        <form className='home-form' onSubmit={handleSubmit}>
          <input className='home-input'
            type="text"
            placeholder="Enter city name"
            value={location} // Controlled input for location
            onChange={(e) => setLocation(e.target.value)} // Update location state on change
          />
          <button className='home-button' type="submit">Get Weather</button>
        </form>
        {error && <p className="error">{error}</p>}
        <label className='home-label'>
          <input 
            type="checkbox" 
            checked={autoUpdate} // Controlled checkbox for auto-update
            onChange={() => setAutoUpdate(!autoUpdate)} // Toggle auto-update state
          />
          Enable Auto-Update (every 5 minutes)
        </label>
      </div>

      {weatherData && ( // Check if weatherData exists before rendering charts
        <div className="weather-info">
          <h1>Data for {weatherData.city}</h1>
          <WeatherChart weatherData={weatherData} />
          <RainTodayChart rainData={weatherData.rainToday} dates={weatherData.dates} />
        </div>
      )}
    </div>
  );
};

export default Home; // Export Home component