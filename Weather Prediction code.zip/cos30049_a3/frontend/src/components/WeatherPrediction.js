import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Plot from 'react-plotly.js';
import './WeatherChart.css'; // Ensure CSS is imported

const WeatherPrediction = () => {
    const [rainData, setRainData] = useState(null);
    const [tempData, setTempData] = useState(null);
    const [error, setError] = useState(null);

    const fetchPredictions = async () => {
        try {
            const [rainResponse, tempResponse] = await Promise.all([
                axios.get('http://127.0.0.1:8000/get/rain'),
                axios.get('http://127.0.0.1:8000/get/temp')
            ]);
            setRainData(rainResponse.data);
            setTempData(tempResponse.data);
            setError(null); // Reset error if data fetch is successful
        } catch (err) {
            console.error(err);
            setError('Failed to fetch weather predictions. Please try again.');
        }
    };

    useEffect(() => {
        fetchPredictions(); // Fetch predictions when the component mounts
        
        const interval = setInterval(() => {
            fetchPredictions(); // Fetch predictions at regular intervals
        }, 1000); // Polling interval

        return () => clearInterval(interval); // Clear interval on component unmount
    }, []);

    // Prepare data for Plotly
    const rainPredictionData = [
        {
            x: ['Prediction'],
            y: [rainData ? (rainData.prediction === 'Y' ? 1 : 0) : 0], // Convert 'Y'/'N' to numeric
            type: 'bar',
            name: 'Rain Prediction',
            marker: { color: 'blue' }
        }
    ];

    const rainProbabilityData = [
        {
            x: ['Probability'],
            y: [rainData ? parseFloat(rainData.probability * 100).toFixed(2) : 0], // Convert to percentage
            type: 'bar',
            name: 'Rain Probability',
            marker: { color: 'lightblue' }
        }
    ];

    const tempPlotData = [
        {
            x: ['Temperature Prediction'],
            y: [tempData ? tempData.prediction : 0],
            type: 'bar',
            name: 'Temperature Prediction',
            marker: { color: 'orange' }
        }
    ];

    const rainPredictionLayout = {
        title: {
            text: 'Rain Predictions',
            font: { size: 24 },
            x: 0.5,
            xanchor: 'center',
            y: 0.95,
        },
        xaxis: { title: 'Predictions', fixedrange: true },
        yaxis: { title: 'Value (0 = No, 1 = Yes)' },
        autosize: true,
        dragmode: 'zoom',
        legend: { orientation: 'h', x: 0.5, y: 0.95, xanchor: 'center', yanchor: 'bottom', bgcolor: 'rgba(255, 255, 255, 0.8)', bordercolor: 'black', borderwidth: 1 },
    };

    const rainProbabilityLayout = {
        title: {
            text: 'Rain Probability',
            font: { size: 24 },
            x: 0.5,
            xanchor: 'center',
            y: 0.95,
        },
        xaxis: { title: 'Predictions', fixedrange: true },
        yaxis: { title: 'Probability (%)', range: [0, 100] },
        autosize: true,
        dragmode: 'zoom',
        legend: { orientation: 'h', x: 0.5, y: 0.95, xanchor: 'center', yanchor: 'bottom', bgcolor: 'rgba(255, 255, 255, 0.8)', bordercolor: 'black', borderwidth: 1 },
    };

    const tempLayout = {
        title: {
            text: 'Temperature Predictions',
            font: { size: 24 },
            x: 0.5,
            xanchor: 'center',
            y: 0.95,
        },
        xaxis: { title: 'Predictions', fixedrange: true },
        yaxis: { title: 'Temperature (°C)' },
        autosize: true,
        dragmode: 'zoom',
        legend: { orientation: 'h', x: 0.5, y: 0.95, xanchor: 'center', yanchor: 'bottom', bgcolor: 'rgba(255, 255, 255, 0.8)', bordercolor: 'black', borderwidth: 1 },
    };

    return (
        <div>
            {error && <p style={{ color: 'red' }}>{error}</p>}

            {/* Rain Predictions Chart */}
            <div className="chart-container">
                <Plot
                    data={rainPredictionData}
                    layout={rainPredictionLayout}
                    config={{ responsive: true, displayModeBar: true }}
                    style={{ width: '100%', height: '100%' }}
                />
            </div>
            
            {/* Rain Probability Chart */}
            <div className="chart-container">
                <Plot
                    data={rainProbabilityData}
                    layout={rainProbabilityLayout}
                    config={{ responsive: true, displayModeBar: true }}
                    style={{ width: '100%', height: '100%' }}
                />
            </div>

            {/* Temperature Predictions Chart */}
            <div className="chart-container">
                <Plot
                    data={tempPlotData}
                    layout={tempLayout}
                    config={{ responsive: true, displayModeBar: true }}
                    style={{ width: '100%', height: '100%' }}
                />
            </div>
        </div>
    );
};

export default WeatherPrediction;