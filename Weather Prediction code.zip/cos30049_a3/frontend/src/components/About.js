import React from 'react';
import './About.css'; // Import the CSS file for styles

//importing images from assets file 
import { Kim } from '../assets/images'; 
import { Jerome } from '../assets/images';
import { Matt } from '../assets/images';
import { report } from '../assets/images';

const About = () => {
  return (
    <div className="about-container">
      <h1>About This Project</h1>
      <div className="project-info">
        <h2>Project Information</h2>
        <p style={{textAlign:'justify'}}>
        SKYCAST is a full-stack web application designed for weather analysis that integrates modern technologies, 
        utilizing React.js for a dynamic and user-friendly front end and FASTAPI for a fast and efficient back end. 
        The application captures user inputs, validates them, and processes them through an AI model developed in a previous assignment to provide accurate weather predictions. 
        With features such as robust error management and engaging data visualizations, SKYCAST enhances user experience by making complex weather data accessible and understandable. 
        Overall, it exemplifies the effective integration of AI and web technologies, delivering valuable insights into weather patterns while ensuring a seamless interaction for users.
        </p>
      </div>

      <div className="developer-info">
        <h2>About the Developers</h2>
        
        {/* Developer 1 */}
        <div className="developer-details">
          <img
            src={Kim} 
            alt="Kim Yao Chua"
            className="developer-image"
          />
          <div className="developer-description">
            <h3>Kim Yao Chua</h3>
            <p style={{textAlign:'justify'}}>
            Kim is the primary front-end developer for SKYCAST, responsible for designing and 
            implementing the user interface using React.js. He focused on creating an intuitive 
            and visually engaging experience for users, ensuring seamless interaction and clear data 
            visualization.
            </p>
          </div>
        </div>

        {/* Developer 2 */}
        <div className="developer-details">
          <img
            src={Jerome} 
            alt="Jerome Liao"
            className="developer-image"
          />
          <div className="developer-description">
            <h3>Jerome Liao</h3>
            <p style={{textAlign:'justify'}}>
            Jerome contributed to both the front-end and back-end development, 
            bridging the gap between design and functionality. He helped refine 
            the user interface and also supported the integration of the FastAPI backend, 
            ensuring that the application functions smoothly across all components.
            </p>
          </div>
        </div>

        {/* Developer 3 */}
        <div className="developer-details">
          <img
            src={Matt} 
            alt="Matthew Dumicich"
            className="developer-image"
          />
          <div className="developer-description">
            <h3>Matthew Dumicich</h3>
            <p style={{textAlign:'justify'}}>
            Matthew handled the back-end development, focusing on the integration of the AI model 
            with FastAPI to process user inputs and deliver accurate weather predictions. His work 
            ensures efficient data processing and robust back-end functionality, making SKYCAST 
            responsive and reliable.
            </p>
          </div>
        </div>
      </div>

      <div className="links">
        <h2>Links</h2>
        <ul>
          <li>
            <a href="https://github.com/KimYaoCHUA/COS30049_A3" target="_blank" rel="noopener noreferrer">
              GitHub Repository
            </a>
          </li>
          <li>
            <a href={report} target="_blank" rel="noopener noreferrer">
              Project Report
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default About;