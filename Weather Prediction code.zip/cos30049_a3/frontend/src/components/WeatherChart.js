import React from 'react';
import Plot from 'react-plotly.js';
import './WeatherChart.css';

const WeatherChart = ({ weatherData }) => {
  const data = [
    {
      x: weatherData.dates, // Use all dates for zooming out
      y: weatherData.minTemp,
      type: 'scatter',
      mode: 'lines+markers',
      name: 'Min Temperature (°C)',
      line: { color: 'blue' },
    },
    {
      x: weatherData.dates, // Use all dates for zooming out
      y: weatherData.maxTemp,
      type: 'scatter',
      mode: 'lines+markers',
      name: 'Max Temperature (°C)',
      line: { color: 'red' },
    },
  ];

  // Filter to show only today's hourly data initially
  const todayData = {
    x: weatherData.hourlyDates,
    y: weatherData.hourlyMaxTemp,
    type: 'scatter',
    mode: 'lines+markers',
    name: 'Max Temperature Today (°C)',
    line: { color: 'orange' },
  };

  const layout = {
    title: {
      text: 'Temperature Forecast',
      font: {
        size: 24, // Font size for title
      },
      x: 0.5, // Center title
      xanchor: 'center', // Anchor center
      y: 0.95, // Adjust y position to move it down
    },
    xaxis: {
      title: 'Date',
      rangemode: 'tozero', // Ensure the x-axis starts from the minimum date
      fixedrange: false, // Allow zooming on the x-axis
    },
    yaxis: {
      title: 'Temperature (°C)',
    },
    autosize: true, // Ensures it automatically sizes to the container
    dragmode: 'zoom', // Enable zooming
    legend: {
      orientation: 'h', // Horizontal orientation
      x: 0.5, // Center horizontally
      y: 0.95, // Position below the title
      xanchor: 'center', // Anchor to center
      yanchor: 'bottom', // Anchor to bottom
      bgcolor: 'rgba(255, 255, 255, 0.8)', // Background color for better visibility
      bordercolor: 'black', // Border color
      borderwidth: 1, // Border width
    },
  };

  return (
    <div className="chart-container">
      <Plot
        data={[...data, todayData]} // Include today’s hourly data in the chart
        layout={layout}
        config={{
          responsive: true, // Make chart responsive
          scrollZoom: true, // Enable scrolling to zoom
          displayModeBar: true, // Show the mode bar
        }}
        style={{ width: '100%', height: '100%' }}
      />
    </div>
  );
};

export default WeatherChart;