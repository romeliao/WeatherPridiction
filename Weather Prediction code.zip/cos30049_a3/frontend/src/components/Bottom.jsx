import React from 'react';
import './Bottom.css'; // Import the CSS file for styles
import { logo } from '../assets/images';  //importing logo png 
import { FaGithub, FaInstagram, FaEnvelope, FaYoutube } from 'react-icons/fa'; // Using react-icons for social media icons

const Bottom = () => {
  return (
    <footer className="bottom-container">
      <div className="logo">
      <img src={logo} alt="Logo" className="logo-image" />
      </div>
      <nav className="bottom-nav">
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/about">About</a></li>
        </ul>
      </nav>
      <div className="social-media">
        <a href="https://github.com/KimYaoCHUA/COS30049_A3" target="_blank" rel="noopener noreferrer">
          <FaGithub className="social-icon" />
        </a>
        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
          <FaInstagram className="social-icon" />
        </a>
        <a href="mailto:your-email@example.com">
          <FaEnvelope className="social-icon" />
        </a>
        <a href="https://youtube.com" target="_blank" rel="noopener noreferrer">
          <FaYoutube className="social-icon" />
        </a>
      </div>
    </footer>
  );
};

export default Bottom;