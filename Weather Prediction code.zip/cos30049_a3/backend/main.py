from fastapi import FastAPI, HTTPException
import weather_prediction
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Allow CORS for all origins (you can restrict it to your frontend's origin)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Update this to specify your frontend origin if needed
    allow_credentials=True,
    allow_methods=["*"],    #allows all HTTP methods
    allow_headers=["*"],    #allow all headers
)

#define global variables to store data from preloading AI
rain_prediction = 0
rain_probability = 0
temp_prediction = 0
#prevents get methods from returning a value if ai has not been preprocessed
input = False

@app.put("/put/data")
async def update_data(MinTemp: float, MaxTemp: float, Rainfall: float):
    #endpoint to update data with minimun temp and max temp and rainfall
    # uses these inputs to get predictions from the AI model
    try:
        #formats weatherdata to be passed to AI
        weather_data = {
            "MinTemp": MinTemp,
            "MaxTemp": MaxTemp,
            "Rainfall": Rainfall
        }

        #defines global variables to store predictions
        global rain_prediction 
        global rain_probability
        global temp_prediction
        global input 

        #predict rain and temp
        rain_prediction, rain_probability, temp_prediction = weather_prediction.main_AI(weather_data)
      
        #store rain and temp in the global variables
        rain_prediction = rain_prediction[0] 
        rain_probability = rain_probability[0]
        temp_prediction = temp_prediction[0]

        #set flag to indicate data has been recieved and predictions are ready
        input = True

        return "Data Recieved"
    #Error Exception Handling
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.get("/get/rain")
async def get_rain_prediction():
    try: 
        # endpoint to retreve rain predictions and probability if data has ben preloaded 
        if input:
            return {
                "prediction": rain_prediction,
                "probability": rain_probability
            }
        else:
            return "No Data Has Been Recieved"
    #Error Exception Handling
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.get("/get/temp")
async def get_temp_prediction():
    try: 
        #return temp predictions if models have been preloaded
        if input:
            return {
                "prediction": temp_prediction,
            }
        else:
            return "No Data Has Been Recieved"
    #Error Exception Handling
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))