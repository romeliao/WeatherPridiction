import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css'; // Import the CSS file for styling
import { logo } from '../assets/images';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <Link to="/">
          <img src={logo} alt="SkyCast Logo" className="logo" /> {/* Add logo image */}
          WeatherApp
        </Link>
      </div>
      <button className={`menu-toggle ${isOpen ? 'toggled' : ''}`} onClick={toggleMenu}>
        <span className={`bar bar-1`}></span>
        <span className={`bar bar-2`}></span>
        <span className={`bar bar-3`}></span>
      </button>
      <ul className={`navbar-links ${isOpen ? 'open' : ''}`}>
        <li><Link to="/" onClick={closeMenu}>Home</Link></li>
        <li><Link to="/about" onClick={closeMenu}>About</Link></li>
      </ul>
    </nav>
  );
};

export default Navbar;