import pandas as pd
import joblib

RAIN_PATH = './rain_prediction.pkl'
TEMP_PATH = './temp_prediction.pkl'

def load_model(path):
    try:
        #load model from pickle file extracted from Assignment 2
        model = joblib.load(path)

        return model
    
    # Error Exception Handling 
    except Exception as e:
        raise Exception(f"Can't load model: {str(e)}")

def prepare_input_data(input_data):
    try:
        #Take the API data and put into a dictionary
        feature_dict = { 
            'MinTemp': [input_data['MinTemp']],
            'MaxTemp': [input_data['MaxTemp']],
            'Rainfall': [input_data['Rainfall']],
        }
        
        #Turn the dictonary into a dataframe
        features = pd.DataFrame(feature_dict)

        return features
    
    # Error Exception Handling 
    except Exception as e:
        raise Exception(f"Error with input data: {str(e)}")

def make_prediction(model, input_data):
    try:
        #predict regression target using model and data from API
        prediction = model.predict(input_data)

        return prediction
    
    # Error Exception Handling 
    except Exception as e:
        raise Exception(f"Prediction Failed: {str(e)}")

def main_AI(data):
        try:
            #load rain and temp models frompickle file
            temp_model = load_model(TEMP_PATH)
            rain_model = load_model(RAIN_PATH)
            
            #put data from api into a dataframe for prediction compatability
            processed_data = prepare_input_data(data)
            
            #make sure the API data contains the correct columns
            print("Processed data columns:", processed_data.columns.tolist())
            print("Processed data types:", processed_data.dtypes)
            
            #predict rain tomorrow with probability
            rain_prediction = make_prediction(rain_model, processed_data)
            rain_probability = rain_model.predict_proba(processed_data)

            #map the outcome of rain prediction to yes or no for readability
            rain_prediction_mapped = 'Yes' if rain_prediction[0] == 1 else 'No'

            #predict temp tomorrow
            temp_prediction = make_prediction(temp_model, processed_data)
            
            return rain_prediction_mapped, rain_probability[0], temp_prediction
        
        # Error Exception Handling 
        except Exception as e:
            raise Exception(f"Error in main_AI: {str(e)}")
