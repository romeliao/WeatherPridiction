import React from 'react';
import { Bar } from 'react-chartjs-2';
import './RainTodayChart.css';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

// Register necessary components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const RainTodayChart = ({ rainData, dates }) => {
  const data = {
    labels: dates,
    datasets: [
      {
        label: 'Rain Today (Yes=1, No=0)',
        data: rainData,
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };


  return (
    <div className="rain-today-chart">
      <Bar data={data}/>
    </div>
  );
};

export default RainTodayChart;